/* -*- Mode: C; indent-tabs-mode: nil; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * unlink_mmap_segment.c
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 *
 * ${PRO} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ${PRO} is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#include "mmap_segment.h"

int unlink_mmap_segment(const char *storage_id)
{
    //////////////////////////////////////////////////////////////////////////
    /// Checks if the storage id pointer is valid
    if (storage_id == NULL)
    {
        perror("Invalid storage id pointer provided.");
        return MMAP_ERROR;
    }

    //////////////////////////////////////////////////////////////////////////
    /// Unlinks (removes) shared memory segment from system
    if (shm_unlink(storage_id) == -1)
    {
        perror("Failed to unlink shared memory segment.");
        return MMAP_ERROR;
    }

    return MMAP_SUCCESS;
}

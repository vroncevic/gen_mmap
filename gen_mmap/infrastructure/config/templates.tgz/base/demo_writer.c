/* -*- Mode: C; indent-tabs-mode: nil; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * demo_writer.c
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 *
 * ${PRO} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ${PRO} is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#include "mmap_segment.h"

int main(int argc, char *argv[])
{
    char buffer[MMAP_STORAGE_SIZE];
    memset(buffer, 0, sizeof(buffer));

    if (argc > 1)
    {
        strncpy(buffer, argv[1], sizeof(buffer) - 1);
    }
    else
    {
        snprintf(
            buffer, sizeof(buffer),
            "Hello from ${PRO} mmap writer! (PID: %d)", getpid()
        );
    }

    printf("[Writer] Writing to shared memory segment: %s\n", MMAP_STORAGE_ID);
    printf("[Writer] Payload: '%s'\n", buffer);

    if (write_mmap_segment(MMAP_STORAGE_ID, buffer) == MMAP_ERROR)
    {
        fprintf(stderr, "[Writer] Failed to write mmap segment.\n");
        return 1;
    }

    printf("[Writer] Data successfully written to shared memory segment.\n");
    printf("[Writer] Now run 'demo_reader' to read and verify the payload.\n");

    return 0;
}

/* -*- Mode: C; indent-tabs-mode: nil; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * demo_reader.c
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 *
 * ${PRO} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ${PRO} is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#include "mmap_segment.h"

int main(void)
{
    char buffer[MMAP_STORAGE_SIZE];
    memset(buffer, 0, sizeof(buffer));

    printf("[Reader] Reading from shared memory segment: %s\n", MMAP_STORAGE_ID);

    if (read_mmap_segment(MMAP_STORAGE_ID, buffer) == MMAP_ERROR)
    {
        fprintf(stderr, "[Reader] Failed to read mmap segment.\n");
        return 1;
    }

    printf("[Reader] Data read successfully.\n");
    printf("[Reader] Payload: '%s'\n", buffer);

    printf("[Reader] Cleaning up and unlinking shared memory segment: %s\n", MMAP_STORAGE_ID);
    if (unlink_mmap_segment(MMAP_STORAGE_ID) == MMAP_ERROR)
    {
        fprintf(stderr, "[Reader] Failed to unlink mmap segment.\n");
        return 1;
    }

    printf("[Reader] Shared memory segment successfully unlinked.\n");
    return 0;
}
